## Architecture

Design document goes here.